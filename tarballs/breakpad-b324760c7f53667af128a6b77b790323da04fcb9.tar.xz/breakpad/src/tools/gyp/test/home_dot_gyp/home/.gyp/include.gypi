{
  'variables': {
    'foo': '"fromhome"',
  },
}
