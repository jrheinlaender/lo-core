{
  'variables': {
    'foo': '"fromhome2"',
  },
}
