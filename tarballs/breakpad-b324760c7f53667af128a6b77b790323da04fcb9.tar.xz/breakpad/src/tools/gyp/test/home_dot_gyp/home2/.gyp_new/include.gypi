{
  'variables': {
    'foo': '"fromhome3"',
  },
}
