import java.io.*;
import java.util.*;

class t93 {
public static void main(String[] args) {
InputStream is;
try {
is = t93.class.getResourceAsStream
("./my.properties");
Properties properties = new Properties();
if (is != null) {
properties.load(is);
Enumeration keys = properties.keys();
while (keys.hasMoreElements()) {
String key = (String) keys.nextElement();
if (key.startsWith("Nigel_"))
System.out.println(key);
}
}
else
System.out.println("Nigel_is.Rubbish");
} catch (Exception e) {}
}
}

