
class BshTest {

	static interface Function {
		public Object _result();
	}

	static class SomeClass {
		static SomeClass newFromMap(java.util.HashMap map) {
			return new SomeClass();
		}
	}

	public static Object test() {

		return SomeClass.newFromMap(((java.util.HashMap) new Function() {
			public Object _result() {
				java.util.HashMap _m = new java.util.HashMap();
				_m.put("foo", "bar");
				return _m;
			}
		}._result()));
	}

	public static void main(String[] args) {
		System.out.println(test());
	}
}
