/* -*- Mode: C++; c-default-style: "k&r"; indent-tabs-mode: nil; tab-width: 2; c-basic-offset: 2 -*- */

/* libmwaw
* Version: MPL 2.0 / LGPLv2+
*
* The contents of this file are subject to the Mozilla Public License Version
* 2.0 (the "License"); you may not use this file except in compliance with
* the License or as specified alternatively below. You may obtain a copy of
* the License at http://www.mozilla.org/MPL/
*
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*
* Major Contributor(s):
* Copyright (C) 2002 William Lachance (wrlach@gmail.com)
* Copyright (C) 2002,2004 Marc Maurer (uwog@uwog.net)
* Copyright (C) 2004-2006 Fridrich Strba (fridrich.strba@bluewin.ch)
* Copyright (C) 2006, 2007 Andrew Ziem
* Copyright (C) 2011, 2012 Alonso Laurent (alonso@loria.fr)
*
*
* All Rights Reserved.
*
* For minor contributions see the git repository.
*
* Alternatively, the contents of this file may be used under the terms of
* the GNU Lesser General Public License Version 2 or later (the "LGPLv2+"),
* in which case the provisions of the LGPLv2+ are applicable
* instead of those above.
*/

/* This header contains code specific to a mac file :
 *     - a namespace used to convert Mac SJIS font characters in unicode
 */

#ifndef MWAW_FONT_SJIS_CONVERTER
#  define MWAW_FONT_SJIS_CONVERTER

#include <map>

#include "libmwaw_internal.hxx"

/*! \brief a namespace used to convert Mac SJIS font characters in unicode
 */
class MWAWFontSJISConverter
{
public:
  //! the constructor
  MWAWFontSJISConverter();
  //! the destructor
  ~MWAWFontSJISConverter();

  //! try to return a unicode for a shift jis character ( returns -1 if the character can not be converted )
  int unicode(unsigned char c, MWAWInputStreamPtr &input);
  //! try to return a unicode for a shift jis character ( returns -1 if the character can not be converted )
  int unicode(unsigned char c, unsigned char const *(&str), int len);
  //!init the mapping
  void initMap();
protected:
  //! a map sjis->unicode
  std::map<int,int> m_sjisUnicodeMap;
};

#endif

// vim: set filetype=cpp tabstop=2 shiftwidth=2 cindent autoindent smartindent noexpandtab:
