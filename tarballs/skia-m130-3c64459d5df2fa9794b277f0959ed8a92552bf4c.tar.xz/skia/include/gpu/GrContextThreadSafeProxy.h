/*
 * Copyright 2019 Google Inc.
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */
// TODO(kjlubick, egdaniel) Delete this after migrating clients.
#include "include/gpu/ganesh/GrContextThreadSafeProxy.h"
